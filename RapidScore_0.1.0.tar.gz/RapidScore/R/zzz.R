loadModule("scoremodule", TRUE)
loadModule("rapidscoremodule", TRUE)
